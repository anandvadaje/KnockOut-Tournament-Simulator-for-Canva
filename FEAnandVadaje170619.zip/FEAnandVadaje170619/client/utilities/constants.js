const ENDPOINTS = {
  TOURNAMENT_ENDPOINT: '/tournament',
  TEAM_ENDPOINT: '/team',
  MATCH_SCORE_ENDPOINT: '/match',
  WINNER_ENDPOINT: '/winner'
}

const TOURNAMENT = {
  FIRST_ROUND: 0,
};
